
const Lang = imports.lang;

const St = imports.gi.St;
const Main = imports.ui.main;
const Gio = imports.gi.Gio;
const GLib = imports.gi.GLib;
const Clutter = imports.gi.Clutter;

const GnomeDesktop = imports.gi.GnomeDesktop;
const GWeather = imports.gi.GWeather;
const PanelMenu = imports.ui.panelMenu;

const ExtensionUtils = imports.misc.extensionUtils;
const Me = ExtensionUtils.getCurrentExtension();
const Convenience = Me.imports.convenience;
const ExtensionSystem = imports.ui.extensionSystem;

const PopupMenu = imports.ui.popupMenu;

const Gtk = imports.gi.Gtk;

const Gettext_dt = imports.gettext.domain('desktop_translations');
const _dt = Gettext_dt.gettext;

let clock, buttons = [], gnomeClockSettings, mySettings, clocksSettings, extensionSig, locations, lang_is_rtl;

const WorldClockMultiButton = new Lang.Class({
  Name: 'WorldClockMultiButton',
  Extends: PanelMenu.Button,

  _init: function (lbt) {
    this.parent(0.25);

    this._myClockDisp = new St.Label({
      y_align: Clutter.ActorAlign.CENTER,
      opacity: 150
    });
    this.actor.add_actor(this._myClockDisp);

    this._place = new St.Label({ style_class: 'location-label' });
    this._sunrise = new St.Label();
    this._sunset = new St.Label();

    let m = this.menu;
    m.box.add(this._place);

    let box = new St.BoxLayout({ style_class: 'location-day' });
    this._dayIcon = new St.Icon({
      icon_size: 15,
      icon_name: 'weather-clear-symbolic',
      opacity: 150,
      style_class: 'location-sunrise-icon'
    });
    box.add_actor(this._dayIcon);
    box.add_actor(this._sunrise);
    
    this._nightIcon = new St.Icon({
      icon_size: 15,
      icon_name: 'weather-clear-night-symbolic',
      style_class: 'location-sunset-icon'
    });
    box.add_actor(this._nightIcon);
    box.add_actor(this._sunset);
    m.box.add(box);

    this._selectLoc = new PopupMenu.PopupSubMenuMenuItem(_("Locations"));
    m.addMenuItem(this._selectLoc);

    this.setLbt(lbt);
  },

  setLbt: function (lbt) {
    this._lbt = lbt;
    this._gwInfo = GWeather.Info.new(lbt._loc, GWeather.ForecastType.ZONE);
    this._gwInfo.set_enabled_providers(GWeather.Provider.NONE);

    let nameMap = mySettings.get_value('name-map').deep_unpack();
    if (nameMap[lbt.code]) {
      this._place.set_text(nameMap[lbt.code]);
    }
    else {
      this._place.set_text(lbt.displayName);
    }
    this.make_loc_menu();
    this.refresh();
  },

  _fromUnix: function (time) {
    return GLib.DateTime.new_from_unix_utc(time).to_timezone(this._lbt._tz);
  },

  refresh: function () {
    this._myClockDisp.set_text(this._lbt.getTime());
    let i = this._gwInfo;
    i.update();

    let night_icon_key = 'weather-clear-night';
    let moonPhase_icon_name = castInt(i.get_value_moonphase()[1]/10) + "0";
    while (moonPhase_icon_name.length < 3) { moonPhase_icon_name = "0" + moonPhase_icon_name; }
    moonPhase_icon_name = night_icon_key + "-" + moonPhase_icon_name;

    if (!Gtk.IconTheme.get_default().has_icon(moonPhase_icon_name)) {
      moonPhase_icon_name = night_icon_key + '-symbolic';
    }
      
    let sunrise = i.get_value_sunrise();
    let sunriseTime = this._fromUnix(sunrise[1]);
    let sunset = i.get_value_sunset();
    let sunsetTime = this._fromUnix(sunset[1]);

    this._dayIcon.set_icon_name(!sunrise[0] && !i.is_daytime() ? moonPhase_icon_name : 'weather-clear-symbolic');
    this._nightIcon.set_icon_name(!sunset[0] && i.is_daytime() ? 'weather-clear-symbolic' : moonPhase_icon_name);

    this._dayIcon.set_opacity(!sunrise[0] && !i.is_daytime() ? 255 : 150);
    this._nightIcon.set_opacity(!sunset[0] && i.is_daytime() ? 150 : 255);

    this._sunrise.set_text(sunrise[0] ? sunriseTime.format(_(Convenience.get12hTimeFormat(sunriseTime))) : "\u2014\u2014");
    this._sunset.set_text(sunset[0] ? sunsetTime.format(_(Convenience.get12hTimeFormat(sunsetTime))) : "");
  },

  make_loc_menu: function () {
    let lm = this._selectLoc.menu;
    lm.removeAll();
    let that = this;
    let skipLocal = mySettings.get_boolean('hide-local');
    let nameMap = mySettings.get_value('name-map').deep_unpack();
    let entries = 0;
    locations.map(function (loc) {
      let lbt = new Convenience.LocationBasedTime(loc);
      if (skipLocal && lbt.tzSameAsLocal()) { return; }
      let display = lbt.displayName2;
      if (nameMap[lbt.code]) {
	let [,sfx] = display.match(/ \((\w+)\)$/);
	display = nameMap[lbt.code] + (sfx ? " (" + sfx + ")" : "");
      }

      // rtl time fix
      if (lang_is_rtl)
	display = "\u202a" + display + "\u202c";
    
      let item = new PopupMenu.PopupMenuItem(display);
      item.location = lbt;
      item.setOrnament(lbt.code == that._lbt.code ? PopupMenu.Ornament.DOT : PopupMenu.Ornament.NONE);
      lm.addMenuItem(item);
      entries += 1;
      item.connect('activate', function (actor) {
	that.switchLbt(actor.location);
	saveButtonConfig();
      });
    });

    if (entries <= 1)
      this._selectLoc.actor.hide();
    else
      this._selectLoc.actor.show();
  },

  switchLbt: function (lbt) {
    let lastLoc = this._lbt;
    if (lastLoc.code == lbt.code) { return; }
    buttons.map(function (x) {
      if (x._lbt.code == lbt.code) {
	x.setLbt(lastLoc);
      }
    });
    this.setLbt(lbt);    
  }
});

function castInt(num) {
    return ~~num;
}

function saveButtonConfig() {
  let config = buttons.map(function (x) { return x._lbt.code; });
  mySettings.set_value('active-buttons', new GLib.Variant('as', config));
}

function init() {
  
}

let remaking;

function remakeButtons() {
  if (remaking) { return; }
  remaking = true;
  
  buttons.map(function (x) {
    x.destroy();
  });
  buttons = locations.map(function (loc) {
    let lbt = new Convenience.LocationBasedTime(loc);
    let btn = new WorldClockMultiButton(lbt);
    btn.refresh();
    return btn;
  });

  let i = 0;
  mySettings.get_value('active-buttons').deep_unpack().map(function (c) {
    let ob = buttons.filter(function (b) { return b._lbt.code == c; });
    if (ob[0] && buttons[i]) {
      buttons[i].switchLbt(ob[0]._lbt);
      i += 1;
    }
  });
  saveButtonConfig();

  let g = 1;
  ['', '2'].map(function(dual) {
    if (dual == '2' && mySettings.get_string('button-position') == mySettings.get_string('button-position2')) {
      return;
    }
    let j = 1;
    let position = mySettings.get_string('button-position' + dual);
    let box_ref = ({
      'L': Main.panel._leftBox,
      'M': Main.panel._centerBox,
      'R': Main.panel._rightBox
    })[position[0]];
    let box_name = ({
      'L': 'left',
      'M': 'center',
      'R': 'right'
    })[position[0]];
    let start_position = ({
      'L': 0,
      '1': 1,
      '9': box_ref.get_n_children() - 1,
      'R': box_ref.get_n_children()
    })[position[1]];
    let numButtons = mySettings.get_value('num-buttons' + dual).deep_unpack();
    let skipLocal = mySettings.get_boolean('hide-local');
    let done = 0;
    buttons.map(function (x) {
      if (skipLocal && x._lbt.tzSameAsLocal()) { return; }
      done += 1;
      if (done < g) { return; }
      if (j <= numButtons) {
	Main.panel.addToStatusArea('worldClock'+g, x, start_position + j - 1, box_name);
	j += 1;
	g += 1;
      }
    });
  });

  remaking = false;
}

function refreshLocations() {
  let world = GWeather.Location.new_world(true);
  
  let world_clocks = clocksSettings.get_value('world-clocks');
  locations = world_clocks.deep_unpack().map(function (e) {
    return world.deserialize(e.location);
  });

  remakeButtons();
}

function enable() {
  clock = new GnomeDesktop.WallClock();

  mySettings = Convenience.getSettings();
  clocksSettings =  Convenience.getClocksSettings();
  gnomeClockSettings = new Gio.Settings({ schema: 'org.gnome.desktop.interface' });
  Convenience.gnomeClockSettings = gnomeClockSettings;
  Convenience.extensionSystem = ExtensionSystem;

  // rtl time fix
  lang_is_rtl = (Clutter.get_default_text_direction() == Clutter.TextDirection.RTL);

  refreshLocations();

  let refreshAll = function () {
    buttons.map(function (x) {
      x.refresh();
    });
  };

  clock.connect('notify::clock', refreshAll);
  
  gnomeClockSettings.connect('changed::clock-format', refreshAll);
  let hook_extn = function(extn) {
    if (extn.state == ExtensionSystem.ExtensionState.ENABLED && extn.stateObj &&
	!extn.stateObj.settingsChanged.world_clock_hook) {	
      extn.stateObj.settingsChanged.world_clock_hook = refreshAll;
    }
  };
  let lunar = ExtensionUtils.extensions['lunarcal@ailin.nemui'];
  if (lunar) {
    hook_extn(lunar);
  }
  extensionSig = ExtensionSystem.connect('extension-state-changed', function (signal, extn) {
    if (extn.uuid != 'lunarcal@ailin.nemui') { return; }
    hook_extn(extn);
    refreshAll();
  });

  clocksSettings.connect('changed::world-clocks', refreshLocations);
  mySettings.connect('changed', remakeButtons);
  clock.connect('notify::timezone', remakeButtons);
}


function disable() {
  ExtensionSystem.disconnect(extensionSig);
  extensionSig = null;
  locations = [];
  buttons.map(function (x) {
    x.destroy();
  });
  buttons = [];
  clock.run_dispose();
  clock = null;
  gnomeClockSettings.run_dispose();
  gnomeClockSettings = null;
  clocksSettings.run_dispose();
  clocksSettings = null;
  mySettings.run_dispose();
  mySettings = null;
}
