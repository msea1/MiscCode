
const Gio = imports.gi.Gio;
const Gtk = imports.gi.Gtk;
const GnomeDesktop = imports.gi.GnomeDesktop;
const ExtensionUtils = imports.misc.extensionUtils;
const Me = ExtensionUtils.getCurrentExtension();
const Convenience = Me.imports.convenience;

let settings, clocksSettings, openWinsCounter, clock;

function init() {
}

let position_inhibitor = false;

function buildPrefsWidget() {
  let ui = new Gtk.Builder(), win = new Gtk.Table();
  ui.add_from_file(Me.dir.get_child('prefs.ui').get_path());

  ui.get_object('content-table').reparent(win);

  if (!settings) {
    settings = Convenience.getSettings();
    clocksSettings = Convenience.getClocksSettings();    
    clock = new GnomeDesktop.WallClock();
    openWinsCounter = 0;
  }
  else {
    openWinsCounter = openWinsCounter + 1;
  }

  let customTheme = new Gtk.CssProvider();
  customTheme.load_from_file(Me.dir.get_child('stylesheet.css'));
  Gtk.StyleContext.add_provider_for_screen(win.get_screen(), customTheme, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION);
  
  settings.bind('hide-local', ui.get_object('local-cb'), 'active', Gio.SettingsBindFlags.DEFAULT);
  settings.bind('num-buttons', ui.get_object('num-adj'), 'value', Gio.SettingsBindFlags.DEFAULT);
  settings.bind('num-buttons2', ui.get_object('num-adj2'), 'value', Gio.SettingsBindFlags.DEFAULT);


  let positions_button_syms = ['LR', 'ML', 'M1', 'MR', 'RL'];
  let positionFromSetting = function() {
    if (position_inhibitor) { return; }
    position_inhibitor = true;
    positions_button_syms.map(function (pos_symbol) {
      ui.get_object('position-' + pos_symbol)
	.set_active(pos_symbol == settings.get_string('button-position') ||
		    pos_symbol == settings.get_string('button-position2'));
    });
    if ((settings.get_string('button-position') == settings.get_string('button-position2'))) {
      ui.get_object('num-sp2').hide();
    } else {
      ui.get_object('num-sp2').show();
    }
    position_inhibitor = false;
  };
  let middleOf = function (a, b, c) {
    return (((a + (b-a)/2)-((c-1)/2))*1.1+((c-1)/2));
  };
  positions_button_syms.map(function (pos_symbol) {
    let cl = pos_symbol;
    ui.get_object('position-' + cl).connect('toggled', function(object) {
      let cl2 = cl;
      if (position_inhibitor) { return; }
      position_inhibitor = true;
      if (cl2 == settings.get_string('button-position2')) {
	settings.set_string('button-position2', settings.get_string('button-position'));
      } else if (cl2 == settings.get_string('button-position')) {
	settings.set_string('button-position', settings.get_string('button-position2'));
      } else if (middleOf(positions_button_syms.indexOf(settings.get_string('button-position')), positions_button_syms.indexOf(settings.get_string('button-position2')), positions_button_syms.length) < positions_button_syms.indexOf(cl)) {
	settings.set_string('button-position2', cl);
      } else {
	settings.set_string('button-position', cl);
      }
      position_inhibitor = false;
      positionFromSetting();
    });
  });
  positionFromSetting();
  settings.connect('changed::button-position', positionFromSetting);
  settings.connect('changed::button-position2', positionFromSetting);
  
  win.connect('destroy', function () {
    if (!openWinsCounter) {
      settings.run_dispose();
      settings = null;
      clocksSettings.run_dispose();
      clocksSettings = null;
      clock.run_dispose();
      clock = null;
    }
    else {
      openWinsCounter = openWinsCounter - 1;
    }
  });
  
  win.show();
  return win;
}
